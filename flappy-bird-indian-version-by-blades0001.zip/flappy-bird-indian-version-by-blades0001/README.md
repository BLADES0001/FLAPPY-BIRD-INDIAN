# Flappy Bird Indian Version by BLADES0001

A Pen created on CodePen.io. Original URL: [https://codepen.io/BLADES0001/pen/xbKRLmY](https://codepen.io/BLADES0001/pen/xbKRLmY).

H! IT IS A FLAPPY BIRD INDIAN GAME MADE BY BLADES0001. Just play it!